DreamCity Package 1.1.0
Leé manifest.json primero. Especificación: docs/export/dream-city-package-spec.md del repositorio City-builder-Dream-Rally.
Las rutas son relativas a la raíz del ZIP. Unidades en metros, Y arriba, sistema diestro (igual que glTF y Godot).
